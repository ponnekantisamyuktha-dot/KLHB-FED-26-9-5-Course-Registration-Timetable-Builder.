# Course Registration & Timetable Builder

## Project Title

**Course Registration & Timetable Builder**

A smart web-based academic management system for course selection, timetable planning, validation, and registration.

## Team Details

| Name | Student ID | GitHub Username |
|---|---|---|
| Nitya Sri | 2620030620 | `nityasri-ops` |
| Samyuktha | 2620030204 | `ponnekantisamyuktha - dot` |
| Mihika Kaki | 2620080022 | `kakimihika-hub` |

- **Team ID:** 5
- **Branch:** CSE
- **Academic Year:** 2026–2027
- **Supervisor:** Rakesh
- **Course Coordinator:** Rakesh

> Note: The GitHub username for Samyuktha should be verified before using it for collaborator access because the supplied username contains spaces.

---

## Abstract

The Course Registration & Timetable Builder is a web-based academic management system designed to simplify course selection and timetable planning. Instead of making students manually compare course availability, timings, credits, seats, and clashes, the system brings these tasks together in one platform.

Students can browse courses, view detailed information, select subjects, and generate a weekly timetable. Before registration, the system checks seat availability, credit limits, prerequisites, and timetable conflicts. Faculty can view assigned courses and schedules, while administrators can manage students, courses, faculty, rooms, schedules, and registration records.

The project aims to provide a centralized, rule-driven workflow for selecting, validating, visualizing, and registering courses.

---

## Problem Statement

The manual course-registration process can require students to repeatedly check:

- Available courses
- Course timings and days
- Faculty and classroom information
- Available seats
- Credit requirements
- Prerequisites
- Timetable clashes
- Courses to register or drop

The proposed system brings these checks into one platform.

---

## Objectives

1. Provide secure student, faculty, and administrator login.
2. Create a searchable course catalog with complete details.
3. Allow students to select, remove, register, and drop courses.
4. Automatically calculate total registered credits.
5. Detect timetable conflicts before registration is finalized.
6. Generate a clear weekly timetable from selected courses.
7. Allow administrators to manage students, faculty, rooms, courses, and schedules.
8. Maintain accurate registration data in a relational database.

---

## Users and Roles

### Student
- Browse and search courses
- Select and drop courses
- Build a timetable
- Register for courses
- View registered credits

### Faculty
- View assigned courses
- View enrolled students
- View schedules
- Check class capacity

### Administrator
- Manage users and courses
- Create schedules and rooms
- Manage capacities
- View reports

---

## Key Features

- Course catalog with search and filters
- Course details and seat availability
- Course selection and registration
- Course drop functionality
- Automatic credit calculation
- Timetable clash detection
- Weekly timetable visualization
- Capacity checking
- Prerequisite and credit validation
- Administrator management panel
- Registration records and reports

---

## System Workflow

1. Login
2. Browse courses
3. Select courses
4. Check validation rules
5. Build timetable
6. Register

The validation stage checks:

- Seat availability
- Credit limits
- Prerequisites
- Day and time conflicts

---

## Technology Stack

The current project presentation proposes:

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** PHP
- **Database:** MySQL
- **Version Control:** Git and GitHub

> The implementation stack should be kept consistent with the actual code developed by the team. If the team changes the technology stack, this section must be updated.

---

## Project Structure

```text
Course-Registration-Timetable-Builder/
│
├── src/
│   └── Source code
│
├── docs/
│   └── Project documentation and presentation
│
├── data/
│   └── Project data / documented data-source references
│
├── results/
│   └── Generated outputs, screenshots, and results
│
├── reports/
│   └── Review and final project reports
│
└── README.md
```

---

## Setup Instructions

### Prerequisites

Install the software required by the actual implementation:

- Web browser
- PHP
- MySQL
- A local server environment such as XAMPP, if used by the team
- Git

### Setup

1. Clone this repository.
2. Place the project source in the configured web-server directory if required.
3. Configure PHP according to the project's backend files.
4. Create the required MySQL database.
5. Import the project's database/schema file when it is added to the repository.
6. Update database connection settings in the project configuration.
7. Start the required web server and MySQL service.
8. Open the project through the configured local URL.

> Exact setup commands will be updated after the actual source code and database files are added to the repository.

---

## Execution Instructions

1. Start the required web server and MySQL service.
2. Ensure the database is running and populated with the required project data.
3. Open the project in a web browser through the configured local URL.
4. Log in or register according to the implemented authentication flow.
5. Browse available courses.
6. Select courses.
7. Review validation and timetable information.
8. Register for valid courses.
9. View the generated timetable and registration details.

> These instructions will be finalized after the implementation is available in `src/`.

---

## Database Design

The proposed relational database includes entities such as:

- Student
- Registration
- Course
- Faculty
- Schedule

Primary keys identify records and foreign keys connect related records.

---

## Testing

Planned test cases include:

| Test Case | Expected Result |
|---|---|
| Correct login | Dashboard opens |
| Wrong password | Error message shown |
| Search course | Matching courses displayed |
| Add/remove course | Selection updates |
| Same-day overlapping classes | Conflict warning shown |
| Different-time classes | No conflict |
| Course is full | Registration blocked |
| Credit limit exceeded | Registration blocked |
| Valid registration | Record saved |
| Drop course | Course removed after confirmation |

---

## Current Phase Status

**Current status:** Project planning and repository setup.

### Completed / Available
- Project topic finalized
- Team identified
- Project presentation prepared
- Initial project structure prepared
- Project abstract and requirements documented in the presentation

### In Progress
- GitHub repository organization
- Source-code structure confirmation
- Implementation planning
- Database and web application development

### Next Steps
- Confirm the actual source-code structure with the team
- Add the source code to `src/`
- Add project documentation to `docs/`
- Add data or document the data source in `data/`
- Add project outputs to `results/`
- Add phase reports to `reports/`
- Begin progressive individual commits
- Tag each completed phase (`review-1`, `review-2`, `final`)

> The phase status must be updated as the project progresses.

---

## Future Scope

Possible future enhancements include:

- Smart timetable generation
- Waitlists
- Notifications
- Mobile application
- Calendar synchronization
- AI-assisted recommendations
- Integration with university systems

---

## Contribution and Version Control

Each team member must use their own GitHub account when making project commits so that individual contributions can be verified through Git history.

The repository will be maintained throughout the project duration. Phase deliverables should be tagged appropriately, for example:

```text
review-1
review-2
final
```

The repository should remain accessible to the supervisor and Course Coordinator until final project evaluation is completed.

---

## Project Presentation

The current project presentation is available in:

```text
docs/Project JAVA.pptx
```

